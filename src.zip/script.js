const character = document.getElementById("character");
const block = document.getElementById("block"); 

function start(){
  if(block.classList != "animate2"){
    block.classList.add("animate2");    
    }
}
let score = 0;
function jump(){
  if(character.classList != "animate"){
  character.classList.add("animate");
  }
  setTimeout(function(){
    character.classList.remove("animate");
  }, 500);
  start();
}

const checkDead = setInterval(function(){
  const characterTop = parseInt(window.getComputedStyle(character).getPropertyValue("top"))
  const blockLeft = parseInt(window.getComputedStyle(block).getPropertyValue("left"))
  
  if(blockLeft < 20 && blockLeft > 0 && characterTop >= 130){
      block.style.animation = "none";
      block.style.display = "none";
      alert("Game Over!");
      location.reload();
    }
}, 10)

const checkScreen = setInterval(function(){
  const characterTop = parseInt(window.getComputedStyle(character).getPropertyValue("top"))
  const blockLeft = parseInt(window.getComputedStyle(block).getPropertyValue("left"))
  
  if(blockLeft === 12){
    document.querySelector("h1").innerHTML = `Score: ${score + 1}`;
    ++score;
    }
}, 17)
/*setInterval(function(){
  const characterTop = parseInt(window.getComputedStyle(block).getPropertyValue("left"))
  console.log(characterTop)
})*/
